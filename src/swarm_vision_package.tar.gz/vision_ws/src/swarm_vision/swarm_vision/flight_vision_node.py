import rclpy
from rclpy.node import Node
from std_msgs.msg import String

import cv2
import time
import os
import threading
import numpy as np
import onnxruntime as ort
from datetime import datetime

# Model Path
MODEL_PATH = '/root/vision_ws/yolo11n.onnx'
session = None
if os.path.exists(MODEL_PATH):
    session = ort.InferenceSession(MODEL_PATH, providers=['CPUExecutionProvider'])
else:
    print(f"CRITICAL: Model file not found at {MODEL_PATH}")

# 80 Standard COCO Classes
COCO_CLASSES = {
    0: 'person', 1: 'bicycle', 2: 'car', 3: 'motorcycle', 4: 'airplane', 5: 'bus',
    6: 'train', 7: 'truck', 8: 'boat', 9: 'traffic light', 10: 'fire hydrant',
    11: 'stop sign', 12: 'parking meter', 13: 'bench', 14: 'bird', 15: 'cat',
    16: 'dog', 17: 'horse', 18: 'sheep', 19: 'cow', 20: 'elephant', 21: 'bear',
    22: 'zebra', 23: 'giraffe', 24: 'backpack', 25: 'umbrella', 26: 'handbag',
    27: 'tie', 28: 'suitcase', 29: 'frisbee', 30: 'skis', 31: 'snowboard',
    32: 'sports ball', 33: 'kite', 34: 'baseball bat', 35: 'baseball glove',
    36: 'skateboard', 37: 'surfboard', 38: 'tennis racket', 39: 'bottle',
    40: 'wine glass', 41: 'cup', 42: 'fork', 43: 'knife', 44: 'spoon', 45: 'bowl',
    46: 'banana', 47: 'apple', 48: 'sandwich', 49: 'orange', 50: 'broccoli',
    51: 'carrot', 52: 'hot dog', 53: 'pizza', 54: 'donut', 55: 'cake',
    56: 'chair', 57: 'couch', 58: 'potted plant', 59: 'bed', 60: 'dining table',
    61: 'toilet', 62: 'tv', 63: 'laptop', 64: 'mouse', 65: 'remote',
    66: 'keyboard', 67: 'cell phone', 68: 'microwave', 69: 'oven', 70: 'toaster',
    71: 'sink', 72: 'refrigerator', 73: 'book', 74: 'clock', 75: 'vase',
    76: 'scissors', 77: 'teddy bear', 78: 'hair drier', 79: 'toothbrush'
}

# Runtime Globals
cap = None
is_detection_enabled = False
active_classes = [32]  # Default: Sports Ball
last_saved_time = 0

# Image Logging Directory
SAVE_DIR = '/root/flight_tests/detections'
os.makedirs(SAVE_DIR, exist_ok=True)

ros_node = None

class FlightVisionNode(Node):
    def __init__(self):
        super().__init__('flight_vision_node')
        
        # Declarations
        self.declare_parameter('uav_id', 'UAV_1')
        self.uav_id = self.get_parameter('uav_id').get_parameter_value().string_value
        
        # Swarm Communications
        self.cmd_pub = self.create_publisher(String, '/swarm/vision_command', 10)
        self.trigger_sub = self.create_subscription(
            String, 
            '/swarm/vision_trigger', 
            self.trigger_callback, 
            10
        )
        
        self.get_logger().info(f"Streamless Flight Node online for {self.uav_id}. Listening to /swarm/vision_trigger")

    def trigger_callback(self, msg):
        global is_detection_enabled, active_classes
        payload = msg.data.strip().upper()
        
        # Supported trigger patterns:
        # 1. "START" -> starts with default class (32)
        # 2. "START:32" -> starts with class 32
        # 3. "START:32,0,29" -> starts with multiple classes
        # 4. "STOP" -> stops detection loop
        
        if payload.startswith("START"):
            if ":" in payload:
                try:
                    classes_str = payload.split(":")[1]
                    parsed_classes = [int(c.strip()) for c in classes_str.split(",") if c.strip().isdigit()]
                    if parsed_classes:
                        active_classes = parsed_classes
                except Exception as e:
                    self.get_logger().error(f"Failed to parse class IDs: {e}")
            
            is_detection_enabled = True
            class_names = [COCO_CLASSES.get(cid, str(cid)) for cid in active_classes]
            self.get_logger().info(f"Detection ACTIVE. Target classes: {active_classes} ({class_names})")
            
        elif payload in ["STOP", "DISABLE"]:
            is_detection_enabled = False
            self.get_logger().info("Detection IDLE/STOPPED.")

    def publish_command(self, action_str):
        msg = String()
        msg.data = f"{self.uav_id}:{action_str}"
        self.cmd_pub.publish(msg)
        self.get_logger().info(f"Published Swarm Command: {msg.data}")

def preprocess_image(img, input_size=(320, 320)):
    h, w = img.shape[:2]
    resized = cv2.resize(img, input_size)
    rgb = cv2.cvtColor(resized, cv2.COLOR_BGR2RGB)
    tensor = rgb.astype(np.float32) / 255.0
    tensor = np.transpose(tensor, (2, 0, 1))
    tensor = np.expand_dims(tensor, axis=0)
    return tensor, w / input_size[0], h / input_size[1]

def run_onnx_inference(frame):
    global session, active_classes
    if session is None:
        return False, frame
    
    input_name = session.get_inputs()[0].name
    tensor, scale_x, scale_y = preprocess_image(frame, (320, 320))
    outputs = session.run(None, {input_name: tensor})
    
    predictions = np.squeeze(outputs[0]).T
    scores = predictions[:, 4:]
    class_ids = np.argmax(scores, axis=1)
    confidences = np.max(scores, axis=1)
    
    boxes = []
    filtered_confidences = []
    filtered_class_ids = []
    
    for i in range(len(confidences)):
        if confidences[i] > 0.45:
            cid = int(class_ids[i])
            if cid in active_classes:
                xc, yc, bw, bh = predictions[i, :4]
                x1 = int((xc - bw / 2) * scale_x)
                y1 = int((yc - bh / 2) * scale_y)
                w = int(bw * scale_x)
                h = int(bh * scale_y)
                
                boxes.append([x1, y1, w, h])
                filtered_confidences.append(float(confidences[i]))
                filtered_class_ids.append(cid)
                
    indices = cv2.dnn.NMSBoxes(boxes, filtered_confidences, score_threshold=0.45, nms_threshold=0.45)
    
    detected = False
    if len(indices) > 0:
        detected = True
        for i in indices.flatten():
            x, y, w, h = boxes[i]
            cid = filtered_class_ids[i]
            conf = filtered_confidences[i]
            cname = COCO_CLASSES.get(cid, f"ID:{cid}")
            
            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
            label = f"{cname} {int(conf * 100)}%"
            (tw, th), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
            y_text = max(y, th + 5)
            cv2.rectangle(frame, (x, y_text - th - 4), (x + tw + 4, y_text + 2), (0, 255, 0), -1)
            cv2.putText(frame, label, (x + 2, y_text - 2), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1)
            
    return detected, frame

def vision_loop():
    global cap, ros_node, is_detection_enabled, last_saved_time
    
    while True:
        if not is_detection_enabled:
            time.sleep(0.08)
            continue
            
        if cap is None or not cap.isOpened():
            time.sleep(0.05)
            continue
            
        success, raw_frame = cap.read()
        if not success:
            time.sleep(0.01)
            continue
            
        detected, annotated_frame = run_onnx_inference(raw_frame)
        current_time = time.time()
        
        if detected:
            if ros_node is not None:
                ros_node.publish_command("TARGET_DETECTED_LAND")
                
            # Rate limit disk saving to maximum 1 snapshot per second
            if current_time - last_saved_time >= 1.0:
                last_saved_time = current_time
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                save_path = os.path.join(SAVE_DIR, f"detection_{timestamp}.jpg")
                threading.Thread(target=cv2.imwrite, args=(save_path, annotated_frame)).start()

def main(args=None):
    global ros_node, cap
    cap = cv2.VideoCapture(0)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

    worker_thread = threading.Thread(target=vision_loop, daemon=True)
    worker_thread.start()

    rclpy.init(args=args)
    ros_node = FlightVisionNode()

    try:
        rclpy.spin(ros_node)
    except KeyboardInterrupt:
        pass
    finally:
        if cap is not None:
            cap.release()
        ros_node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
