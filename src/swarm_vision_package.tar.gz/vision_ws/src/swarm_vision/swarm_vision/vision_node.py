import rclpy
from rclpy.node import Node
from std_msgs.msg import String

import cv2
import time
import os
import io
import zipfile
import threading
import numpy as np
import onnxruntime as ort
from datetime import datetime
from flask import Flask, Response, render_template_string, request, jsonify, send_file

app = Flask(__name__)

# بارگذاری مدل پایدار و عمومی YOLO11n
MODEL_PATH = '/root/vision_ws/yolo11n.onnx'
session = None
if os.path.exists(MODEL_PATH):
    session = ort.InferenceSession(MODEL_PATH, providers=['CPUExecutionProvider'])
else:
    print(f"هشدار: فایل مدل در {MODEL_PATH} یافت نشد!")

# ۸۰ کلاس رسمی COCO
COCO_CLASSES = {
    0: 'person', 1: 'bicycle', 2: 'car', 3: 'motorcycle', 4: 'airplane', 5: 'bus',
    6: 'train', 7: 'truck', 8: 'boat', 9: 'traffic light', 10: 'fire hydrant',
    11: 'stop sign', 12: 'parking meter', 13: 'bench', 14: 'bird', 15: 'cat',
    16: 'dog', 17: 'horse', 18: 'sheep', 19: 'cow', 20: 'elephant', 21: 'bear',
    22: 'zebra', 23: 'giraffe', 24: 'backpack', 25: 'umbrella', 26: 'handbag',
    27: 'tie', 28: 'suitcase', 29: 'frisbee', 30: 'skis', 31: 'snowboard',
    32: 'sports ball', 33: 'kite', 34: 'baseball bat', 35: 'baseball glove',
    36: 'skateboard', 37: 'surfboard', 38: 'tennis racket', 39: 'bottle',
    40: 'wine glass', 41: 'cup', 42: 'fork', 43: 'knife', 44: 'spoon', 45: 'bowl',
    46: 'banana', 47: 'apple', 48: 'sandwich', 49: 'orange', 50: 'broccoli',
    51: 'carrot', 52: 'hot dog', 53: 'pizza', 54: 'donut', 55: 'cake',
    56: 'chair', 57: 'couch', 58: 'potted plant', 59: 'bed', 60: 'dining table',
    61: 'toilet', 62: 'tv', 63: 'laptop', 64: 'mouse', 65: 'remote',
    66: 'keyboard', 67: 'cell phone', 68: 'microwave', 69: 'oven', 70: 'toaster',
    71: 'sink', 72: 'refrigerator', 73: 'book', 74: 'clock', 75: 'vase',
    76: 'scissors', 77: 'teddy bear', 78: 'hair drier', 79: 'toothbrush'
}

np.random.seed(42)
CLASS_COLORS = np.random.randint(50, 255, size=(len(COCO_CLASSES), 3), dtype=np.uint8)

# متغیرهای سیستمی
cap = None
stream_quality = 50
inference_skip = 1
selected_classes = [32]      # پیش‌فرض: Sports Ball (توپ)
detect_all = False
digital_zoom = 1.0

recording_test = False
enable_video_record = True
current_test_name = ""
current_test_dir = ""
test_start_time = None
last_save_time = 0
latest_notification = "سیستم آماده پایش سوارم است."
target_currently_detected = False

latest_annotated_frame = None
frame_lock = threading.Lock()

video_writer = None
BASE_TEST_DIR = os.path.expanduser("/root/flight_tests")
os.makedirs(BASE_TEST_DIR, exist_ok=True)

ros_node = None

class SwarmVisionNode(Node):
    def __init__(self):
        super().__init__('vision_node')
        
        # دریافت شناسه پرنده (پیش‌فرض: UAV_1)
        self.declare_parameter('uav_id', 'UAV_1')
        self.uav_id = self.get_parameter('uav_id').get_parameter_value().string_value
        
        # تاپیک مشترک و سراسری سوارم
        self.cmd_pub = self.create_publisher(String, '/swarm/vision_command', 10)
        self.get_logger().info(f'نود بینایی پرنده {self.uav_id} روی تاپیک سراسری /swarm/vision_command فعال شد.')

    def publish_command(self, command_str):
        msg = String()
        # ارسال پیام متنی با فرمت: UAV_1:TARGET_DETECTED_LAND
        msg.data = f"{self.uav_id}:{command_str}"
        self.cmd_pub.publish(msg)
        self.get_logger().info(f'مخابره به سوارم: {msg.data}')

def get_cpu_temp():
    try:
        with open("/sys/class/thermal/thermal_zone0/temp", "r") as f:
            temp = float(f.read()) / 1000.0
            return f"{temp:.1f}°C"
    except Exception:
        return "N/A"

def apply_digital_zoom(frame, zoom_factor):
    if zoom_factor <= 1.0:
        return frame
    h, w = frame.shape[:2]
    new_h, new_w = int(h / zoom_factor), int(w / zoom_factor)
    y1, y2 = (h - new_h) // 2, ((h - new_h) // 2) + new_h
    x1, x2 = (w - new_w) // 2, ((w - new_w) // 2) + new_w
    cropped = frame[y1:y2, x1:x2]
    return cv2.resize(cropped, (w, h), interpolation=cv2.INTER_LINEAR)

def preprocess_image(img, input_size=(320, 320)):
    h, w = img.shape[:2]
    resized = cv2.resize(img, input_size)
    rgb = cv2.cvtColor(resized, cv2.COLOR_BGR2RGB)
    tensor = rgb.astype(np.float32) / 255.0
    tensor = np.transpose(tensor, (2, 0, 1))
    tensor = np.expand_dims(tensor, axis=0)
    return tensor, w / input_size[0], h / input_size[1]

def run_onnx_inference(frame):
    global session, selected_classes, detect_all
    if session is None:
        return False, frame
    
    input_name = session.get_inputs()[0].name
    tensor, scale_x, scale_y = preprocess_image(frame, (320, 320))
    outputs = session.run(None, {input_name: tensor})
    
    predictions = np.squeeze(outputs[0]).T
    scores = predictions[:, 4:]
    class_ids = np.argmax(scores, axis=1)
    confidences = np.max(scores, axis=1)
    
    boxes = []
    filtered_confidences = []
    filtered_class_ids = []
    
    for i in range(len(confidences)):
        if confidences[i] > 0.45:
            cid = int(class_ids[i])
            if detect_all or (cid in selected_classes):
                xc, yc, bw, bh = predictions[i, :4]
                x1 = int((xc - bw / 2) * scale_x)
                y1 = int((yc - bh / 2) * scale_y)
                w = int(bw * scale_x)
                h = int(bh * scale_y)
                
                boxes.append([x1, y1, w, h])
                filtered_confidences.append(float(confidences[i]))
                filtered_class_ids.append(cid)
                
    indices = cv2.dnn.NMSBoxes(boxes, filtered_confidences, score_threshold=0.45, nms_threshold=0.45)
    
    detected = False
    if len(indices) > 0:
        detected = True
        for i in indices.flatten():
            x, y, w, h = boxes[i]
            cid = filtered_class_ids[i]
            conf = filtered_confidences[i]
            cname = COCO_CLASSES.get(cid, f"ID:{cid}")
            color = [int(c) for c in CLASS_COLORS[cid % len(CLASS_COLORS)]]
            
            cv2.rectangle(frame, (x, y), (x + w, y + h), color, 2)
            label = f"{cname} {int(conf * 100)}%"
            (tw, th), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
            y_text = max(y, th + 5)
            cv2.rectangle(frame, (x, y_text - th - 4), (x + tw + 4, y_text + 2), color, -1)
            cv2.putText(frame, label, (x + 2, y_text - 2), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
            
    return detected, frame

def vision_loop():
    global cap, digital_zoom, ros_node, target_currently_detected
    global recording_test, enable_video_record, video_writer, last_save_time, latest_notification
    global inference_skip, latest_annotated_frame
    
    prev_time = 0
    frame_count = 0
    cached_detected = False
    
    while True:
        if cap is None or not cap.isOpened():
            time.sleep(0.05)
            continue
            
        success, raw_frame = cap.read()
        if not success:
            continue
            
        frame = apply_digital_zoom(raw_frame, digital_zoom)
        frame_count += 1
        current_time = time.time()
        
        if frame_count % inference_skip == 0:
            detected, annotated_frame = run_onnx_inference(frame)
            cached_detected = detected
        else:
            detected = cached_detected
            annotated_frame = frame.copy()
            
        target_currently_detected = detected
        
        # مخابره پیام روی تاپیک واحد با ساختار UAV_1:TARGET_DETECTED_LAND
        if detected and ros_node is not None:
            ros_node.publish_command("TARGET_DETECTED_LAND")

        fps = 1.0 / (current_time - prev_time) if (current_time - prev_time) > 0 else 0
        prev_time = current_time
        
        sys_clock = datetime.now().strftime("%H:%M:%S")
        test_timer_str = "00:00"
        if recording_test and test_start_time:
            elapsed = int(current_time - test_start_time)
            mins, secs = divmod(elapsed, 60)
            test_timer_str = f"{mins:02d}:{secs:02d}"

        cpu_temp = get_cpu_temp()
        cv2.putText(annotated_frame, f"FPS: {fps:.1f} | Temp: {cpu_temp} | Zoom: {digital_zoom:.1f}x", 
                    (15, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 255, 0), 2)
        
        timer_display = f"Time: {sys_clock}"
        if recording_test:
            timer_display += f" | Test: {test_timer_str}"
            cv2.circle(annotated_frame, (frame.shape[1] - 25, 25), 8, (0, 0, 255), -1)
            if enable_video_record:
                cv2.putText(annotated_frame, "REC VID", (frame.shape[1] - 110, 30),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)

        cv2.putText(annotated_frame, timer_display, 
                    (15, frame.shape[0] - 15), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 255, 255), 2)

        if recording_test:
            if enable_video_record and video_writer is not None:
                video_writer.write(annotated_frame)

            if detected:
                latest_notification = "🎯 هدف در کادر است! ارسال سیگنال سوارم..."
                if current_time - last_save_time >= 1.0:
                    last_save_time = current_time
                    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                    filename = os.path.join(current_test_dir, f"img_{timestamp}.jpg")
                    threading.Thread(target=cv2.imwrite, args=(filename, annotated_frame.copy())).start()
            else:
                latest_notification = "در حال پایش منطقه... هدفی یافت نشد."

        with frame_lock:
            latest_annotated_frame = annotated_frame.copy()

def generate_frames():
    global latest_annotated_frame, stream_quality
    while True:
        with frame_lock:
            if latest_annotated_frame is None:
                frame = np.zeros((480, 640, 3), dtype=np.uint8)
            else:
                frame = latest_annotated_frame.copy()
                
        ret, buffer = cv2.imencode('.jpg', frame, [int(cv2.IMWRITE_JPEG_QUALITY), stream_quality])
        if not ret:
            time.sleep(0.03)
            continue
            
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + buffer.tobytes() + b'\r\n')
        time.sleep(0.03)

HTML_PAGE = """
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>پنل پایش سوارم - نود ROS 2</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body { font-family: Tahoma, Arial, sans-serif; background: #0f111a; color: #e1e1e1; margin: 0; padding: 15px; text-align: center; }
        .main-container { display: flex; flex-wrap: wrap; justify-content: center; gap: 20px; max-width: 1350px; margin: auto; }
        .stream-container { flex: 1 1 620px; max-width: 700px; background: #000; border-radius: 10px; overflow: hidden; border: 1px solid #222; }
        img { width: 100%; height: auto; display: block; }
        .panel { flex: 1 1 350px; background: #1a1d2e; padding: 18px; border-radius: 10px; border: 1px solid #2c304d; text-align: right; }
        .box { background: #23273e; padding: 12px; border-radius: 6px; margin-bottom: 12px; }
        .notif-box { background: #132438; border-right: 4px solid #00a8ff; color: #bde0fe; padding: 10px; font-weight: bold; }
        button { padding: 8px 14px; font-size: 13px; border: none; border-radius: 5px; cursor: pointer; color: #fff; font-family: inherit; font-weight: bold; }
        .btn-start { background: #27ae60; width: 100%; }
        .btn-stop { background: #c0392b; width: 100%; }
        .btn-dl { background: #2980b9; padding: 4px 8px; font-size: 12px; }
        input, select { padding: 7px; border-radius: 4px; border: 1px solid #444; background: #111; color: #fff; font-family: inherit; }
        label { font-size: 12px; color: #bbb; display: block; margin-top: 5px; }
        .test-list { max-height: 120px; overflow-y: auto; list-style: none; padding: 0; margin: 5px 0 0 0; }
        .test-item { display: flex; justify-content: space-between; align-items: center; padding: 5px; border-bottom: 1px solid #333; font-size: 12px; }
        .checkbox-container { max-height: 140px; overflow-y: auto; background: #111; padding: 8px; border-radius: 5px; border: 1px solid #444; margin-top: 5px; }
        .checkbox-item { display: flex; align-items: center; gap: 8px; font-size: 12px; margin-bottom: 4px; }
        .checkbox-item input { width: auto; margin: 0; }
        .toggle-box { background: #182333; border: 1px solid #254466; padding: 8px; border-radius: 5px; margin-top: 8px; }
    </style>
</head>
<body onclick="initAudio()">
    <h2>🚁 پنل مدیریت ویژن سوارم (تاپیک سراسری)</h2>
    
    <div class="main-container">
        <div class="stream-container">
            <img src="/video_feed">
        </div>

        <div class="panel">
            <div class="box notif-box" id="notif-text">سیستم آماده است.</div>

            <div class="box">
                <strong>🔍 کنترل زوم دیجیتال:</strong>
                <label>ضریب زوم: <span id="zval" style="color: #00d2d3; font-weight: bold;">1.0x</span></label>
                <input type="range" min="1.0" max="4.0" step="0.1" value="1.0" style="width:100%" onchange="setZoom(this.value)" oninput="document.getElementById('zval').innerText=parseFloat(this.value).toFixed(1)+'x'">
            </div>

            <div class="box">
                <strong>⚡ روانی استریم و مصرف پردازنده:</strong>
                <label>Skip Frame اینفرنس: <span id="skval">هر 1 فریم</span></label>
                <input type="range" min="1" max="4" value="1" style="width:100%" onchange="setSkip(this.value)" oninput="document.getElementById('skval').innerText='هر ' + this.value + ' فریم'">

                <label>کیفیت استریم شبکه: <span id="qv" style="color: #f39c12;">50%</span></label>
                <input type="range" min="15" max="95" value="50" style="width:100%" onchange="setQuality(this.value)" oninput="document.getElementById('qv').innerText=this.value+'%'">
            </div>

            <div class="box">
                <label>انتخاب کلاس‌های مورد نظر برای کشف هدف:</label>
                <div class="checkbox-item">
                    <input type="checkbox" id="chk-all" onchange="toggleAllClasses(this.checked)">
                    <label for="chk-all" style="color:#2ecc71; margin:0;">همه اشیاء (Detect All)</label>
                </div>
                <div class="checkbox-container" id="class-container">
                    {% for cid, cname in classes.items() %}
                    <div class="checkbox-item">
                        <input type="checkbox" class="cls-box" value="{{ cid }}" id="cls_{{ cid }}" {% if cid in active_cls %}checked{% endif %} onchange="updateSelectedClasses()">
                        <label for="cls_{{ cid }}" style="margin:0;">{{ cid }}: {{ cname }}</label>
                    </div>
                    {% endfor %}
                </div>
            </div>

            <div class="box">
                <label>مدیریت تست پرواز گروهی:</label>
                <div id="start-controls">
                    <input type="text" id="test-name" placeholder="نام تست پرواز (مثلا SWARM_T1)" style="width: calc(100% - 16px);">
                    <div class="toggle-box checkbox-item">
                        <input type="checkbox" id="chk-video-rec" checked onchange="toggleVideoRec(this.checked)">
                        <label for="chk-video-rec" style="color:#3498db; margin:0; cursor:pointer;">ضبط ویدیوی کل تست</label>
                    </div>
                    <button class="btn-start" style="margin-top: 10px;" onclick="startTest()">شروع تست و تایمر</button>
                </div>
                <div id="stop-controls" style="display: none;">
                    <p id="active-test-label" style="color: #2ecc71; margin: 4px 0;"></p>
                    <button class="btn-stop" onclick="stopTest()">پایان تست</button>
                </div>
            </div>

            <div class="box">
                <strong>📁 دانلود فایل‌های ماموریت:</strong>
                <ul class="test-list" id="test-list-ui">
                    <li>درحال بارگذاری...</li>
                </ul>
            </div>
        </div>
    </div>

    <script>
        let audioCtx = null, lastBeepTime = 0;
        function initAudio() { if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)(); }
        function playBeep() {
            initAudio(); let now = Date.now();
            if (now - lastBeepTime < 1000) return; lastBeepTime = now;
            if (audioCtx && audioCtx.state === 'running') {
                let osc = audioCtx.createOscillator(), gain = audioCtx.createGain();
                osc.type = 'sine'; osc.frequency.value = 880;
                gain.gain.setValueAtTime(0.15, audioCtx.currentTime);
                gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.25);
                osc.connect(gain); gain.connect(audioCtx.destination);
                osc.start(); osc.stop(audioCtx.currentTime + 0.25);
            }
        }
        function updateNotif() {
            fetch('/get_status').then(r => r.json()).then(d => {
                document.getElementById('notif-text').innerText = d.notification;
                if(d.recording) {
                    document.getElementById('start-controls').style.display = 'none';
                    document.getElementById('stop-controls').style.display = 'block';
                    document.getElementById('active-test-label').innerText = 'تست فعال: ' + d.test_name;
                } else {
                    document.getElementById('start-controls').style.display = 'block';
                    document.getElementById('stop-controls').style.display = 'none';
                }
                if (d.detected) playBeep();
            });
        }
        setInterval(updateNotif, 500);

        function loadTests() {
            fetch('/list_tests').then(r => r.json()).then(folders => {
                let html = '';
                if(folders.length === 0) html = '<li style="color:#777;">تستی ثبت نشده است.</li>';
                else folders.forEach(f => { html += `<li class="test-item"><span>${f}</span><a href="/download_test/${f}"><button class="btn-dl">دانلود ZIP</button></a></li>`; });
                document.getElementById('test-list-ui').innerHTML = html;
            });
        }
        setInterval(loadTests, 5000); loadTests();

        function setZoom(val) { fetch('/set_zoom?zoom=' + val); }
        function setSkip(val) { fetch('/set_skip?skip=' + val); }
        function setQuality(val) { fetch('/set_quality?quality=' + val); }
        function updateSelectedClasses() {
            let selected = [];
            document.querySelectorAll('.cls-box:checked').forEach(cb => selected.push(cb.value));
            fetch('/set_classes', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({classes: selected, all: false}) });
        }
        function toggleAllClasses(isAll) {
            fetch('/set_classes', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({classes: [], all: isAll}) });
            document.querySelectorAll('.cls-box').forEach(cb => cb.disabled = isAll);
        }
        function toggleVideoRec(enabled) { fetch('/set_video_rec?enable=' + (enabled ? 1 : 0)); }
        function startTest() {
            initAudio(); var name = document.getElementById('test-name').value.trim();
            if(!name) { alert('لطفاً نام تست را وارد کنید.'); return; }
            fetch('/start_test?name=' + encodeURIComponent(name)).then(() => loadTests());
        }
        function stopTest() { fetch('/stop_test').then(() => loadTests()); }
    </script>
</body>
</html>
"""

@app.route('/')
def index():
    return render_template_string(HTML_PAGE, classes=COCO_CLASSES, active_cls=selected_classes)

@app.route('/video_feed')
def video_feed():
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/get_status')
def get_status():
    return jsonify({
        "notification": latest_notification,
        "recording": recording_test,
        "test_name": current_test_name,
        "detected": target_currently_detected
    })

@app.route('/set_zoom')
def set_zoom():
    global digital_zoom
    digital_zoom = max(1.0, min(float(request.args.get('zoom', 1.0)), 4.0))
    return jsonify(status="ok", zoom=digital_zoom)

@app.route('/set_classes', methods=['POST'])
def set_classes():
    global selected_classes, detect_all
    data = request.get_json()
    detect_all = data.get('all', False)
    selected_classes = [int(c) for c in data.get('classes', [])]
    return jsonify(status="ok")

@app.route('/set_video_rec')
def set_video_rec():
    global enable_video_record
    enable_video_record = (request.args.get('enable', '1') == '1')
    return jsonify(status="ok", enable=enable_video_record)

@app.route('/set_skip')
def set_skip():
    global inference_skip
    inference_skip = max(1, min(int(request.args.get('skip', 1)), 5))
    return jsonify(status="ok", skip=inference_skip)

@app.route('/list_tests')
def list_tests():
    try:
        folders = [d for d in os.listdir(BASE_TEST_DIR) if os.path.isdir(os.path.join(BASE_TEST_DIR, d))]
        folders.sort(reverse=True)
        return jsonify(folders)
    except Exception:
        return jsonify([])

@app.route('/download_test/<folder_name>')
def download_test(folder_name):
    folder_path = os.path.join(BASE_TEST_DIR, folder_name)
    if not os.path.exists(folder_path):
        return "پوشه پیدا نشد", 404

    zip_buffer = io.BytesIO()
    with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
        for root, _, files in os.walk(folder_path):
            for file in files:
                file_path = os.path.join(root, file)
                zip_file.write(file_path, arcname=file)
    
    zip_buffer.seek(0)
    return send_file(zip_buffer, mimetype='application/zip', as_attachment=True, download_name=f"{folder_name}.zip")

@app.route('/set_quality')
def set_quality():
    global stream_quality
    stream_quality = max(10, min(request.args.get('quality', default=50, type=int), 95))
    return jsonify(status="ok", quality=stream_quality)

@app.route('/start_test')
def start_test():
    global recording_test, current_test_name, current_test_dir, test_start_time, latest_notification
    global video_writer, enable_video_record
    
    name = request.args.get('name', default='TEST').strip()
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    folder_name = f"{name}_{timestamp}"
    
    current_test_name = name
    current_test_dir = os.path.join(BASE_TEST_DIR, folder_name)
    os.makedirs(current_test_dir, exist_ok=True)
    
    if enable_video_record:
        video_path = os.path.join(current_test_dir, f"full_test_{timestamp}.mp4")
        fourcc = cv2.VideoWriter_fourcc(*'mp4v')
        video_writer = cv2.VideoWriter(video_path, fourcc, 20.0, (640, 480))
    else:
        video_writer = None

    test_start_time = time.time()
    recording_test = True
    latest_notification = f"تست {name} آغاز شد. ضبط فعال است."
    return jsonify(status="ok", dir=current_test_dir)

@app.route('/stop_test')
def stop_test():
    global recording_test, test_start_time, latest_notification, video_writer
    recording_test = False
    test_start_time = None
    if video_writer is not None:
        video_writer.release()
        video_writer = None
    latest_notification = f"تست {current_test_name} پایان یافت."
    return jsonify(status="ok")

def run_flask():
    app.run(host='0.0.0.0', port=5000, debug=False, use_reloader=False)

def main(args=None):
    global ros_node, cap
    cap = cv2.VideoCapture(0)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

    # اجرای ترد مستقل بینایی و هوش مصنوعی
    worker_thread = threading.Thread(target=vision_loop, daemon=True)
    worker_thread.start()

    # اجرای ترد وب‌سرور
    flask_thread = threading.Thread(target=run_flask, daemon=True)
    flask_thread.start()

    rclpy.init(args=args)
    ros_node = SwarmVisionNode()

    try:
        rclpy.spin(ros_node)
    except KeyboardInterrupt:
        pass
    finally:
        if cap is not None:
            cap.release()
        ros_node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
